import { PaymentService } from '../src/payments/PaymentService';

describe('PaymentService', () => {
  let paymentService: PaymentService;

  beforeEach(() => {
    paymentService = new PaymentService();
  });

  it('should calculate tax correctly', () => {
    // Accessing private method for testing purposes (mocking)
    const tax = (paymentService as any).calculateTax(100, 'US-CA');
    expect(tax).toBe(8); // 8.25% rounded
  });

  it('should initialize payment intent', async () => {
    const intent = await paymentService.createPaymentIntent(1000, 'usd', 'cus_123');
    
    expect(intent.id).toBeDefined();
    expect(intent.status).toBe('pending');
    expect(intent.amount).toBeGreaterThan(1000); // Includes tax
  });
});
