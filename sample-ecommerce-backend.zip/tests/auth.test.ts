import { AuthService } from '../src/auth/AuthService';

describe('AuthService', () => {
  let authService: AuthService;

  beforeEach(() => {
    authService = new AuthService();
  });

  it('should hash and validate passwords correctly', async () => {
    const password = 'TestPassword123!';
    const hash = await authService.hashPassword(password);
    
    expect(hash).not.toBe(password);
    
    const isValid = await authService.validatePassword(password, hash);
    expect(isValid).toBe(true);
    
    const isInvalid = await authService.validatePassword('wrongpassword', hash);
    expect(isInvalid).toBe(false);
  });

  it('should generate and verify JWT tokens', () => {
    const payload = { userId: '123', role: 'user', email: 'test@test.com' };
    const token = authService.generateToken(payload);
    
    expect(token).toBeDefined();
    
    const decoded = authService.verifyToken(token);
    expect(decoded.userId).toBe(payload.userId);
    expect(decoded.role).toBe(payload.role);
  });
});
