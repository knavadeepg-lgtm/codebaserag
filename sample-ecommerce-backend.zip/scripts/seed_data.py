import json
import uuid
import random
from datetime import datetime

def generate_mock_data():
    """Generates mock test data for the e-commerce database."""
    print("Seeding database...")
    
    users = []
    for i in range(10):
        users.append({
            "id": str(uuid.uuid4()),
            "email": f"user{i}@example.com",
            "name": f"Test User {i}",
            "role": "admin" if i == 0 else "user",
            "created_at": datetime.now().isoformat()
        })
        
    payments = []
    for i in range(20):
        payments.append({
            "id": str(uuid.uuid4()),
            "user_id": random.choice(users)["id"],
            "amount": random.randint(1000, 50000) / 100.0,
            "currency": "usd",
            "status": random.choice(["succeeded", "pending", "failed"]),
            "created_at": datetime.now().isoformat()
        })
        
    print(f"Generated {len(users)} users and {len(payments)} payments.")
    
    with open('seed_data.json', 'w') as f:
        json.dump({"users": users, "payments": payments}, f, indent=2)
        
    print("Seeding complete.")

if __name__ == "__main__":
    generate_mock_data()
