import { Request, Response, NextFunction } from 'express';
import { paymentService } from './PaymentService';
import { stripeIntegration } from './StripeIntegration';
import { logger } from '../utils/logger';

export class PaymentController {
  
  /**
   * Endpoint to create a new payment intent.
   */
  public async createPayment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { amount, currency } = req.body;
      const userId = (req as any).user.userId;

      if (!amount || amount <= 0) {
        res.status(400).json({ error: 'Valid amount is required' });
        return;
      }

      const intent = await paymentService.createPaymentIntent(amount, currency || 'usd', userId);
      
      res.status(200).json({
        clientSecret: intent.clientSecret,
        paymentId: intent.id
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Endpoint to handle Stripe webhooks for async payment status updates.
   */
  public async webhook(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const signature = req.headers['stripe-signature'] as string;
      const payload = req.body; // Needs to be raw buffer in real app

      // Verify webhook signature
      const event = stripeIntegration.constructWebhookEvent(payload, signature);

      // Handle the event
      switch (event.type) {
        case 'payment_intent.succeeded':
          const paymentIntent = event.data.object;
          logger.info(`PaymentIntent ${paymentIntent.id} was successful!`);
          // Update DB status
          break;
        case 'payment_intent.payment_failed':
          logger.warn(`Payment failed: ${event.data.object.id}`);
          break;
        default:
          logger.debug(`Unhandled event type ${event.type}`);
      }

      res.status(200).json({ received: true });
    } catch (error) {
      logger.error('Webhook error:', error);
      res.status(400).send(`Webhook Error: ${(error as Error).message}`);
    }
  }
}

export const paymentController = new PaymentController();
