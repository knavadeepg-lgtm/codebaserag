import Stripe from 'stripe';
import { logger } from '../utils/logger';

/**
 * Wrapper class for Stripe SDK to encapsulate external dependency.
 */
class StripeIntegration {
  private stripe: Stripe;

  constructor() {
    const apiKey = process.env.STRIPE_SECRET_KEY || 'sk_test_mock_key';
    this.stripe = new Stripe(apiKey, {
      apiVersion: '2023-10-16',
      typescript: true,
    });
  }

  public async createPaymentIntent(amount: number, currency: string, customer?: string) {
    logger.debug(`Stripe API: Creating payment intent for ${amount}`);
    // MOCK implementation for sample
    return {
      id: `pi_mock_${Date.now()}`,
      client_secret: 'secret_mock_12345',
      status: 'requires_payment_method'
    };
  }

  public async refundPayment(paymentIntentId: string, amount?: number) {
    logger.debug(`Stripe API: Refunding payment ${paymentIntentId}`);
    return { id: `re_mock_${Date.now()}`, status: 'succeeded' };
  }

  public async createCustomer(email: string, name: string) {
    logger.debug(`Stripe API: Creating customer ${email}`);
    return { id: `cus_mock_${Date.now()}` };
  }

  public constructWebhookEvent(payload: string | Buffer, signature: string) {
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET || 'whsec_mock';
    // MOCK: return this.stripe.webhooks.constructEvent(payload, signature, endpointSecret);
    return {
      type: 'payment_intent.succeeded',
      data: { object: { id: 'pi_mock_123' } }
    };
  }
}

export const stripeIntegration = new StripeIntegration();
