import { Request, Response, NextFunction } from 'express';
import { authService } from './AuthService';
import { userService } from '../users/UserService';
import { logger } from '../utils/logger';

/**
 * Controller handling authentication endpoints.
 * Interacts with AuthService and UserService.
 */
export class AuthController {
  
  /**
   * Authenticates a user and returns a JWT.
   */
  public async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        res.status(400).json({ error: 'Email and password are required' });
        return;
      }

      const user = await userService.findByEmail(email);
      if (!user) {
        res.status(401).json({ error: 'Invalid credentials' });
        return;
      }

      const isValidPassword = await authService.validatePassword(password, user.passwordHash);
      if (!isValidPassword) {
        res.status(401).json({ error: 'Invalid credentials' });
        return;
      }

      const token = authService.generateToken({
        userId: user.id,
        role: user.role,
        email: user.email
      });

      const refreshToken = authService.generateRefreshToken(user.id);

      res.status(200).json({
        message: 'Login successful',
        user: { id: user.id, email: user.email, name: user.name, role: user.role },
        token,
        refreshToken
      });
    } catch (error) {
      logger.error('Login error:', error);
      next(error);
    }
  }

  /**
   * Creates a new user account and authenticates them.
   */
  public async register(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, password, name } = req.body;

      const existingUser = await userService.findByEmail(email);
      if (existingUser) {
        res.status(409).json({ error: 'Email already in use' });
        return;
      }

      const passwordHash = await authService.hashPassword(password);
      
      const newUser = await userService.createUser({
        email,
        passwordHash,
        name,
        role: 'user'
      });

      const token = authService.generateToken({
        userId: newUser.id,
        role: newUser.role,
        email: newUser.email
      });

      res.status(201).json({
        message: 'Registration successful',
        user: { id: newUser.id, email: newUser.email, name: newUser.name },
        token
      });
    } catch (error) {
      logger.error('Registration error:', error);
      next(error);
    }
  }

  /**
   * Invalidates user session (handled mostly client side, but we could blacklist token).
   */
  public async logout(req: Request, res: Response): Promise<void> {
    // In a stateless JWT setup, logout is mainly clearing the client token.
    // Here we might blacklist the token in Redis if implemented.
    res.status(200).json({ message: 'Logout successful' });
  }

  /**
   * Retrieves the currently authenticated user's profile based on JWT.
   */
  public async getCurrentUser(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      // req.user is populated by AuthMiddleware
      const userId = (req as any).user.userId;
      
      const user = await userService.findById(userId);
      if (!user) {
        res.status(404).json({ error: 'User not found' });
        return;
      }

      res.status(200).json({ user });
    } catch (error) {
      next(error);
    }
  }
}

export const authController = new AuthController();
