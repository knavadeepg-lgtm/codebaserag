import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { logger } from '../utils/logger';

export interface TokenPayload {
  userId: string;
  role: string;
  email: string;
}

/**
 * Service handling all authentication-related business logic.
 * Includes password hashing, JWT generation and validation, and secure tokens.
 */
export class AuthService {
  private readonly JWT_SECRET: string;
  private readonly TOKEN_EXPIRY: string = '24h';
  private readonly REFRESH_TOKEN_EXPIRY: string = '7d';
  private readonly SALT_ROUNDS: number = 12;

  constructor() {
    this.JWT_SECRET = process.env.JWT_SECRET || 'default_secret_for_development_only';
    if (!process.env.JWT_SECRET) {
      logger.warn('JWT_SECRET not set in environment, using default unsafe secret.');
    }
  }

  /**
   * Hashes a plain text password using bcrypt.
   * @param password Plain text password
   * @returns Promise resolving to the hashed password
   */
  public async hashPassword(password: string): Promise<string> {
    try {
      const salt = await bcrypt.genSalt(this.SALT_ROUNDS);
      return await bcrypt.hash(password, salt);
    } catch (error) {
      logger.error('Error hashing password', error);
      throw new Error('Failed to process password');
    }
  }

  /**
   * Validates a plain text password against a stored hash.
   * @param password Plain text password attempt
   * @param hash Stored bcrypt hash
   * @returns Promise resolving to boolean indicating match
   */
  public async validatePassword(password: string, hash: string): Promise<boolean> {
    try {
      return await bcrypt.compare(password, hash);
    } catch (error) {
      logger.error('Error validating password', error);
      return false;
    }
  }

  /**
   * Generates a JWT access token for an authenticated user.
   * @param payload User information to encode
   * @returns Signed JWT string
   */
  public generateToken(payload: Omit<TokenPayload, 'iat' | 'exp'>): string {
    return jwt.sign(
      {
        userId: payload.userId,
        role: payload.role,
        email: payload.email
      },
      this.JWT_SECRET,
      { expiresIn: this.TOKEN_EXPIRY }
    );
  }

  /**
   * Generates a long-lived refresh token.
   * @param userId User identifier
   * @returns Signed refresh token
   */
  public generateRefreshToken(userId: string): string {
    return jwt.sign(
      { userId, type: 'refresh' },
      this.JWT_SECRET,
      { expiresIn: this.REFRESH_TOKEN_EXPIRY }
    );
  }

  /**
   * Verifies and decodes a JWT token.
   * @param token JWT string to verify
   * @returns Decoded token payload
   * @throws Error if token is invalid or expired
   */
  public verifyToken(token: string): TokenPayload {
    try {
      return jwt.verify(token, this.JWT_SECRET) as TokenPayload;
    } catch (error) {
      if (error instanceof jwt.TokenExpiredError) {
        throw new Error('Token has expired');
      }
      throw new Error('Invalid token');
    }
  }

  /**
   * Generates a cryptographically secure random token for password resets.
   * @returns Hex string representing the secure token
   */
  public generateResetToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * Hashes a reset token for storage in the database to prevent plain-text leaks.
   * @param resetToken Plain text reset token
   * @returns SHA-256 hashed token
   */
  public hashResetToken(resetToken: string): string {
    return crypto.createHash('sha256').update(resetToken).digest('hex');
  }
}

export const authService = new AuthService();
