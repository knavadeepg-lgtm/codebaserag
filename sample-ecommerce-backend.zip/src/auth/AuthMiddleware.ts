import { Request, Response, NextFunction } from 'express';
import { authService, TokenPayload } from './AuthService';
import { logger } from '../utils/logger';

// Extend Express Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: TokenPayload;
    }
  }
}

export class AuthMiddleware {
  /**
   * Extracts token from Authorization header (Bearer token)
   */
  private extractToken(req: Request): string | null {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      return authHeader.substring(7);
    }
    return null;
  }

  /**
   * Middleware to ensure a user is authenticated
   */
  public authenticateToken = (req: Request, res: Response, next: NextFunction): void => {
    try {
      const token = this.extractToken(req);

      if (!token) {
        res.status(401).json({ error: 'Authentication required. No token provided.' });
        return;
      }

      const payload = authService.verifyToken(token);
      req.user = payload;
      next();
    } catch (error) {
      logger.warn(`Authentication failed: ${(error as Error).message}`);
      res.status(401).json({ error: 'Invalid or expired token.' });
    }
  };

  /**
   * Middleware for optional authentication.
   * Does not fail if token is missing or invalid, just leaves req.user empty.
   */
  public optionalAuth = (req: Request, res: Response, next: NextFunction): void => {
    const token = this.extractToken(req);
    if (token) {
      try {
        req.user = authService.verifyToken(token);
      } catch (error) {
        // Ignore errors for optional auth
      }
    }
    next();
  };

  /**
   * Middleware for Role-Based Access Control
   * @param roles Array of allowed roles
   */
  public requireRole = (roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction): void => {
      if (!req.user) {
        res.status(401).json({ error: 'Authentication required' });
        return;
      }

      if (!roles.includes(req.user.role)) {
        res.status(403).json({ 
          error: 'Forbidden: You do not have sufficient permissions to access this resource.' 
        });
        return;
      }

      next();
    };
  };
}

export const authMiddleware = new AuthMiddleware();
