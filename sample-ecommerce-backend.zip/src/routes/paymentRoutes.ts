import { Router } from 'express';
import { paymentController } from '../payments/PaymentController';
import { protect } from '../middleware/auth';

const router = Router();

// Webhooks don't use standard JWT auth, they verify stripe signatures
router.post('/webhook', paymentController.webhook);

// Protected payment routes
router.post('/', protect, paymentController.createPayment);
router.post('/:id/refund', protect, (req, res) => res.send('Refund endpoint'));
router.get('/history', protect, (req, res) => res.send('Payment history'));

export default router;
