import { Router } from 'express';
import authRoutes from './authRoutes';
import userRoutes from './userRoutes';
import paymentRoutes from './paymentRoutes';

const router = Router();

// Mount specialized routers
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/payments', paymentRoutes);

export default router;
