import { Router } from 'express';
import { authController } from '../auth/AuthController';
import { protect } from '../middleware/auth';

const router = Router();

// Public auth routes
router.post('/login', authController.login);
router.post('/register', authController.register);
router.post('/forgot-password', (req, res) => res.send('Forgot password'));

// Protected auth routes
router.post('/logout', protect, authController.logout);
router.get('/me', protect, authController.getCurrentUser);

export default router;
