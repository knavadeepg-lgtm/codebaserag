import { Router } from 'express';
import { userController } from '../users/UserController';
import { protect, authorizeAdmin } from '../middleware/auth';

const router = Router();

// Protect all user routes
router.use(protect);

// Current user operations
router.put('/profile', userController.updateProfile);
router.delete('/account', userController.deleteAccount);

// Admin only operations
router.get('/', authorizeAdmin, userController.listUsers);
router.get('/:id', authorizeAdmin, userController.getUserById);

export default router;
