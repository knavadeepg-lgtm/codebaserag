import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

/**
 * Basic memory-based rate limiter middleware mock.
 */
const rateLimitCache = new Map<string, { count: number, resetTime: number }>();

export const rateLimiter = (req: Request, res: Response, next: NextFunction): void => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const WINDOW_MS = 15 * 60 * 1000; // 15 minutes
  const MAX_REQUESTS = 100;

  const now = Date.now();
  let record = rateLimitCache.get(ip);

  if (!record || now > record.resetTime) {
    record = { count: 1, resetTime: now + WINDOW_MS };
  } else {
    record.count++;
  }

  rateLimitCache.set(ip, record);

  if (record.count > MAX_REQUESTS) {
    logger.warn(`Rate limit exceeded for IP: ${ip}`);
    res.status(429).json({ error: 'Too many requests, please try again later.' });
    return;
  }

  // Add rate limit headers
  res.setHeader('X-RateLimit-Limit', MAX_REQUESTS);
  res.setHeader('X-RateLimit-Remaining', MAX_REQUESTS - record.count);

  next();
};
