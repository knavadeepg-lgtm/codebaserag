import { authMiddleware } from '../auth/AuthMiddleware';

/**
 * Re-export auth middleware for easier importing in routes.
 * This acts as the facade for route protection logic.
 */

// Basic authentication check
export const protect = authMiddleware.authenticateToken;

// Optional authentication
export const optionalAuth = authMiddleware.optionalAuth;

// Role-based protection
export const authorizeAdmin = authMiddleware.requireRole(['admin']);
export const authorizeManager = authMiddleware.requireRole(['admin', 'manager']);
