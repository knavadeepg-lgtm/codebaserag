import { logger } from '../utils/logger';
import { dbConfig } from '../../config/database.config';

/**
 * Mock Database Connection Module
 */
class DatabaseConnection {
  private isConnected = false;
  private pool: any = null;

  /**
   * Initializes the database connection pool.
   */
  public async connect(): Promise<void> {
    try {
      logger.info(`Connecting to database at ${dbConfig.host}:${dbConfig.port}...`);
      
      // MOCK Connection logic (e.g. const pool = new pg.Pool(dbConfig))
      await this.mockDelay(500);
      
      this.isConnected = true;
      this.pool = { active: true };
      logger.info('Database connected successfully.');
    } catch (error) {
      logger.error('Database connection failed:', error);
      throw error;
    }
  }

  public getConnection() {
    if (!this.isConnected) {
      throw new Error('Database not connected');
    }
    return this.pool;
  }

  public async close(): Promise<void> {
    if (this.isConnected) {
      logger.info('Closing database connection...');
      await this.mockDelay(200);
      this.isConnected = false;
      this.pool = null;
    }
  }

  private mockDelay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const db = new DatabaseConnection();
export const connectDatabase = () => db.connect();
