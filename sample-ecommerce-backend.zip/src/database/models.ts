export const models = {
  User: {
    tableName: 'users',
    fields: ['id', 'email', 'password_hash', 'name', 'role', 'created_at']
  },
  Payment: {
    tableName: 'payments',
    fields: ['id', 'user_id', 'amount', 'currency', 'status', 'created_at'],
    relations: {
      user: {
        type: 'belongsTo',
        target: 'users',
        foreignKey: 'user_id'
      }
    }
  },
  Session: {
    tableName: 'sessions',
    fields: ['id', 'user_id', 'token', 'expires_at'],
    indexes: ['expires_at', 'token']
  }
};
