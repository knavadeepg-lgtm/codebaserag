/**
 * Interface representing the structure of a User document/record.
 */
export interface IUser {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  role: 'user' | 'admin' | 'manager';
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  stripeCustomerId?: string;
  lastLogin?: Date;
}

/**
 * Mock Model class for User
 * In a real application, this might be a Mongoose Schema or TypeORM Entity.
 */
export class User implements IUser {
  public id: string;
  public email: string;
  public passwordHash: string;
  public name: string;
  public role: 'user' | 'admin' | 'manager';
  public isActive: boolean;
  public createdAt: Date;
  public updatedAt: Date;

  constructor(data: Partial<IUser>) {
    this.id = data.id || '';
    this.email = data.email || '';
    this.passwordHash = data.passwordHash || '';
    this.name = data.name || '';
    this.role = data.role || 'user';
    this.isActive = data.isActive !== undefined ? data.isActive : true;
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
  }

  /**
   * Pre-save validation logic mock
   */
  public validate(): boolean {
    if (!this.email || !this.email.includes('@')) {
      throw new Error('Invalid email format');
    }
    if (!this.passwordHash) {
      throw new Error('Password is required');
    }
    return true;
  }
}
