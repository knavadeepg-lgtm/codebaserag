import { Request, Response, NextFunction } from 'express';
import { userService } from './UserService';
import { logger } from '../utils/logger';

export class UserController {
  /**
   * Retrieves profile for a specific user.
   */
  public async getUserById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const user = await userService.findById(id);
      
      if (!user) {
        res.status(404).json({ error: 'User not found' });
        return;
      }
      
      // Strip sensitive fields
      const { passwordHash, ...safeUser } = user;
      res.status(200).json(safeUser);
    } catch (error) {
      next(error);
    }
  }

  /**
   * Updates user profile.
   */
  public async updateProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.userId;
      const { name, phone, address } = req.body;
      
      const updatedUser = await userService.updateUser(userId, { 
        name,
        // Other fields we allow updating
      });
      
      res.status(200).json({ message: 'Profile updated', user: { name: updatedUser.name } });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Admin: List users with pagination.
   */
  public async listUsers(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      
      // Mock result
      const users = [
        { id: '1', email: 'user1@test.com', role: 'user' },
        { id: '2', email: 'user2@test.com', role: 'admin' }
      ];
      
      res.status(200).json({
        data: users,
        meta: { page, limit, total: 2 }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Deactivates the user's own account.
   */
  public async deleteAccount(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = (req as any).user.userId;
      await userService.deleteUser(userId);
      res.status(200).json({ message: 'Account deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
}

export const userController = new UserController();
