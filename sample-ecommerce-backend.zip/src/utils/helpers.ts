import crypto from 'crypto';

export const generateId = (): string => {
  return crypto.randomUUID();
};

export const formatCurrency = (amount: number, currency = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.toUpperCase()
  }).format(amount / 100); // Assuming amount is in cents
};

export const sanitizeInput = (input: string): string => {
  if (!input) return '';
  return input.replace(/[<>]/g, '');
};

export const paginate = <T>(array: T[], page: number, limit: number): T[] => {
  const startIndex = (page - 1) * limit;
  return array.slice(startIndex, startIndex + limit);
};

export const sleep = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};
