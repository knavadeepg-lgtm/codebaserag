/**
 * Simple logger utility to unify application logging format.
 */
class Logger {
  private formatMessage(level: string, message: string, meta?: any): string {
    const timestamp = new Date().toISOString();
    let str = `[${timestamp}] ${level.toUpperCase()}: ${message}`;
    if (meta) {
      if (meta instanceof Error) {
        str += ` \n${meta.stack}`;
      } else {
        str += ` ${JSON.stringify(meta)}`;
      }
    }
    return str;
  }

  public info(message: string, meta?: any): void {
    console.log(this.formatMessage('info', message, meta));
  }

  public warn(message: string, meta?: any): void {
    console.warn(this.formatMessage('warn', message, meta));
  }

  public error(message: string, meta?: any): void {
    console.error(this.formatMessage('error', message, meta));
  }

  public debug(message: string, meta?: any): void {
    if (process.env.NODE_ENV !== 'production') {
      console.debug(this.formatMessage('debug', message, meta));
    }
  }
}

export const logger = new Logger();
