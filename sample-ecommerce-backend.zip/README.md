# E-Commerce Backend Sample

This is a realistic, mock e-commerce backend built with Node.js, Express, and TypeScript.
It is designed to serve as a sample repository for the CodeLens RAG Assistant project.

## Features
- Complete JWT-based Authentication
- User Management
- Payment Processing with Stripe integration mock
- PostgreSQL Database integration mock
- Comprehensive Middleware architecture

## Setup
1. `npm install`
2. `npm run dev`

Use this repository to test codebase comprehension questions!
